$.components.register("summernote", {
  mode: "default",
  defaults: {
    height: 300
  }
});
