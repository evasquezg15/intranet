[1.0.1] - 2015-07-24
--------------------
### Added
- fooTable plugin
- NProgress.js plugin

[1.0.0] - 2015-07-23
--------------------
- Initial release
