<?php $auth->logOut();?>
<script>
var domain = "<?php echo _DOMAIN;?>";
window.location.href=domain;
</script>