$.components.register("select2", {
  mode: "default",
  defaults: {
    width: "style"
  }
});
