$.components.register("sortable", {
  defaults: {},
  mode: "default"
});
