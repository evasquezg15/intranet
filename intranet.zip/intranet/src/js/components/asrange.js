$.components.register("asRange", {
  mode: "default",
  defaults: {
    tip: false,
    scale: false
  }
});
