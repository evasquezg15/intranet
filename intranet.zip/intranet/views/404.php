  <!-- Page -->
  <div class="page animsition vertical-align text-center" data-animsition-in="fade-in"
  data-animsition-out="fade-out">
    <div class="page-content vertical-align-middle">
      <img class="error-mark animation-slide-top" src="<?php echo _DOMAIN;?>assets/images/404.png" alt="...">
      <h2>Pagina No Encontrada !</h2>
      <p class="error-advise">La página que buscas no existe o no está disponible</p>
      <a class="btn btn-primary btn-round" href="<?php echo _DOMAIN;?>">Ir a la principal</a>

      <footer class="page-copyright">
      </footer>
    </div>
  </div>
  <!-- End Page -->

