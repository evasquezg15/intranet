$.components.register("asSpinner", {
  mode: "default",
  defaults: {
    namespace: "spinnerUi",
    skin: null,
    min: "-10",
    max: 100,
    mousewheel: true
  }
});
