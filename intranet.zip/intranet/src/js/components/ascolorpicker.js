$.components.register("asColorPicker", {
  defaults: {
    namespace: "colorInputUi"
  },
  mode: "default"
});
