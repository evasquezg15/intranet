<?php 
define(_DOMAIN, "http://192.168.1.161/intranet/");
//define(_DOMAIN, "http://localhost/intranet/");
?>