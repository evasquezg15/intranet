$.components.register("nestable", {
  mode: "default"
});
