$.components.register("labelauty", {
  mode: "default",
  defaults: {
    same_width: true
  }
});
