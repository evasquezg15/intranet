$.components.register("clockpicker", {
  mode: "default",
  defaults: {
    donetext: "Done"
  }
});
